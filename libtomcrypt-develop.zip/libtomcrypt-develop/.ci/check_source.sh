#!/bin/bash

# output version
bash .ci/printinfo.sh

make clean > /dev/null

echo "checking..."
./helper.pl --check-all || exit 1

exit 0

# ref:         HEAD -> develop
# git commit:  ddfe2e8aa7c4239463a8a1d26724aef123333549
# commit time: 2022-08-21 11:34:22 +0200
